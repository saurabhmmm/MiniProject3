package com.saurabh.miniproj3.entities;


import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;

public class SSNGenerator implements IdentifierGenerator {

	@Override
	public Serializable generate(SharedSessionContractImplementor session, Object object) throws HibernateException {
		Long ssn=null;
		try {
			Connection con=session.connection();
			Statement st=con.createStatement();
			String query="select ssn_seq.nextval from dual";
			ResultSet rs=st.executeQuery(query);
			if (rs.next())
			 ssn=rs.getLong(1);
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return ssn;
	}

}
