package com.saurabh.miniproj3.exceptions;

public class EnrollmentException extends RuntimeException {

	public EnrollmentException(String string) {
		super(string);
	}
	

}
