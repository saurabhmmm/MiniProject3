package com.saurabh.miniproj3.services;

import java.util.List;

import com.saurabh.miniproj3.bindings.SSNEnrollmentRequest;

public interface SsaService {
	public List<String> getAllStateNames();
	public Long ssnEnrollment(SSNEnrollmentRequest req);
	public String checkEnrollment(Long ssn,String stateName);
}
