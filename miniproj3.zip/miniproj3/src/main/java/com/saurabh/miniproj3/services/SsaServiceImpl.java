package com.saurabh.miniproj3.services;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.saurabh.miniproj3.bindings.SSNEnrollmentRequest;
import com.saurabh.miniproj3.entities.SSNMasterEntity;
import com.saurabh.miniproj3.exceptions.EnrollmentException;
import com.saurabh.miniproj3.repository.SSNMasterRepository;
import com.saurabh.miniproj3.repository.StatesMasterRepository;
@Service
public class SsaServiceImpl implements SsaService {
	@Autowired
	private StatesMasterRepository staterepo;
	@Autowired
	private SSNMasterRepository ssnrepo;
	
	@Override
	public List<String> getAllStateNames() {
		
		return staterepo.findByStateName();
	}

	@Override
	public Long ssnEnrollment(SSNEnrollmentRequest req) {
		SSNMasterEntity entity=new SSNMasterEntity();
		BeanUtils.copyProperties(req, entity);
		SSNMasterEntity savedentity=ssnrepo.save(entity);
		if(savedentity!=null)
		{
			return savedentity.getSsn();
		}
		else throw new EnrollmentException("Enrollment cannot be done!!!");
	}

	@Override
	public String checkEnrollment(Long ssn, String stateName) {
		SSNMasterEntity entity=ssnrepo.findBySsnAndStateName(ssn,stateName);
		if(entity!=null)
			return "VALID";
		return "INVALID";
	}

}
