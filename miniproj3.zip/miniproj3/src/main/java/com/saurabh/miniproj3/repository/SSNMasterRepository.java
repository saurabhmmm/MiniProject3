package com.saurabh.miniproj3.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.saurabh.miniproj3.entities.SSNMasterEntity;

public interface SSNMasterRepository extends JpaRepository<SSNMasterEntity, Long> {
public SSNMasterEntity findBySsnAndStateName(Long ssn,String stateName);
}
