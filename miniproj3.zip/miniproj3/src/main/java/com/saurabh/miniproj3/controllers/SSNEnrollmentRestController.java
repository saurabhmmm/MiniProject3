package com.saurabh.miniproj3.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.saurabh.miniproj3.bindings.SSNEnrollmentRequest;
import com.saurabh.miniproj3.services.SsaService;

@RestController
public class SSNEnrollmentRestController {

	@Autowired
	SsaService service;
	@PostMapping(value="/ssnEnrollment",
			consumes="application/json"
			)
	public ResponseEntity<String> enrollSsn(@RequestBody SSNEnrollmentRequest req)
	{
		Long ssn=service.ssnEnrollment(req);
		String rsbody="Your SSN Enrollment created successfully with SSN: "+ssn;
		return new ResponseEntity<String>(rsbody, HttpStatus.CREATED);
	}
}
