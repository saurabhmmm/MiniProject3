package com.saurabh.miniproj3.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.saurabh.miniproj3.entities.StatesMasterEntity;

public interface StatesMasterRepository extends JpaRepository<StatesMasterEntity, Integer> {
@Query("select stateName  from States_master")
public List<String> findByStateName();
}
