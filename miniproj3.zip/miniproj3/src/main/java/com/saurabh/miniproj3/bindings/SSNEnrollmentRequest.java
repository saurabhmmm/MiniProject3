package com.saurabh.miniproj3.bindings;

import java.util.Date;

import javax.persistence.Column;

import lombok.Data;

@Data
public class SSNEnrollmentRequest {
	private Long ssn;
	
	private String fname;
	
	private String lname;

	private Date dob;
	
	private String gender;
	
	private String stateName;

}
