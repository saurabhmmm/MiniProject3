package com.saurabh.miniproj3.exceptions;

import java.util.Date;

public class ApiError {
	private int errCode;
	private String errMsg;
	private Date date;
	
	
	public ApiError(int errCode, String errMsg, Date date) {
		super();
		this.errCode = errCode;
		this.errMsg = errMsg;
		this.date = date;
	}
	public int getErrCode() {
		return errCode;
	}
	public void setErrCode(int errCode) {
		this.errCode = errCode;
	}
	public String getErrMsg() {
		return errMsg;
	}
	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}

}
