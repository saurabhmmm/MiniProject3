package com.saurabh.miniproj3.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.saurabh.miniproj3.services.SsaService;

@RestController
public class SSNValidationRestController {
	@Autowired
	SsaService service;
	@GetMapping(value="/validateSsn/{ssn}/{state}",
			consumes="application/json")
public ResponseEntity<String> checkSsn(@PathVariable("ssn") String ssn,@PathVariable("state") String stateName) {
	
	String rsbody=	service.checkEnrollment(Long.parseLong(ssn), stateName);
		 return new ResponseEntity<String>(rsbody,HttpStatus.OK);
	}
}
